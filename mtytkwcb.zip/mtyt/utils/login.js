var API_URL = "https://lsq-dev.neoteched.com/v2/check_login";
function Login(url, sucessCallback, method, header) {
  if (wx.getStorageSync("token") && wx.getStorageSync("user") && wx.getStorageSync("user").id) {
    ajax(url, sucessCallback, method, header)
  } else {
    // console.log('code=' + code);
    //创建一个dialog
    wx.showToast({
      title: '正在登录...',
      icon: 'loading',
      duration: 10000
    });
    wx.login({
      success: res => {
      
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        if (res.code != "") {
         var code = res.code;
          wx.setStorageSync("code", code);
          // console.log(wx.getStorageSync("token"));
          //Login(code);
          getToken(res.code, url, sucessCallback, method, header)
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
          // console.log(wx.getStorageSync("token"));              
        }
      },
      fail: function (e) {
        console.log(e);
      }
    })
  }

}


function getToken(code, url, sucessCallback, method, header) {
  //请求服务器
  wx.request({
    url: API_URL,
    data: {
      code: code
    },
    method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'content-type': 'application/json',
      'X-Token': wx.getStorageSync("token")
    }, // 设置请求的 header
    success: res => {
      if (res.data.code == 0) {
        wx.setStorageSync("token", res.data.data.token);
        ajax(url, sucessCallback, method, header);
        wx.getUserInfo({//getUserInfo流程
          success: res2 => {//获取userinfo成功
            // console.log(res2);
            var encryptedData = res2.encryptedData;
            var iv = res2.iv;
            //请求自己的服务器
            wx.request({
              url: API_URL,
              method: "POST",
              header: {
                'content-type': 'application/json',
                'X-Token': wx.getStorageSync("token")
              },
              data: {
                token: wx.getStorageSync("token"),
                iv: iv,
                encryptedData: encryptedData
              },
              success: res3 => {
                // userInfo = res3.data.data.user;
                // console.log(userInfo);
                // console.log(res3);
                wx.setStorageSync("user", res3.data.data);
                if (res3.data.data.id) {
                 
                }
              },
              fail: function () {
                // console.log("flase");
              }
            })
          },
          fail: function () {
            // fail
            // wx.hideToast();
            // console.log(e);
            wx.showModal({
              title: '警告',
              content: '您点击了拒绝授权，将无法正常使用******的功能体验。请10分钟后再次点击授权，或者删除小程序重新进入。',
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定');
                }
              }
            })

          },
        })
      }
      wx.hideToast();
      // console.log(res.data);

    },
    fail: function () {
      // fail
      wx.hideToast();
    },
    complete: function () {
      // complete
    }
  })
}
function ajax(url, sucessCallback, method, header) {

  method = method || "GET";
  header = header || {
    'content-type': 'application/json',
    'X-Token': wx.getStorageSync("token")
  }
  // console.log(sucessCallback)
  sucessCallback=sucessCallback||function(){

  }
  // console.log( sucessCallback)
  wx.request({
    url: url,
    method: method,
    header: header,
    success: res => {
      var codes = res.data.code;
      if (codes == 0) {
        sucessCallback(res)
      } else {
        console.log(res.message)
      }
    }
  })
}

module.exports ={
Login:Login,
ajax:ajax
} ;