//index.js
//获取应用实例
const app = getApp()
var util = require('../../utils/util.js');
var home_url = "https://lsq-dev.neoteched.com/v2/home";
var questionData;
var arrDay;
var year, month, day;
var ans_url = "https://lsq-dev.neoteched.com/v2/question_detail";
var dayTop = {};
Page({
  data: {
  },
  //事件处理函数
  bindAnswerTap: function() {
    var dayTop = this.data.days;
    // console.log(dayTop)
    wx.navigateTo({
      url: './answer/answer?days=' + dayTop,
    })
  }, 
  bindAnswerTap2: function (item) {
    var dayTop2 = item.currentTarget.dataset.days;
    // console.log(dayTop2)
    wx.navigateTo({
      url: './answer/answer?days=' + dayTop2,
    })
  }, 
  bindMineTap: function () {
    wx.reLaunch({
      url: '../mine/mine',
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      // console.log(res.target)
    }
    return {
      title: '法考天天练',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  onLoad: function () {
    // this.getDataHome();
    var flag = this;
    wx.request({
      url: home_url,
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'X-Token': wx.getStorageSync("token")
      },
      success: res => {
        console.log(res.data.code);
        var codes = res.data.code;
        if (codes == 0) {
          flag.getDataHome();
        } else {
          setTimeout(function(){
            flag.getDataHome();
          },2000)
        }
      }
    })
    // console.log(time);
  },
  //定义获取数据函数
  getDataHome: function () {
    var that = this;
    wx.request({
      url: home_url,
      data: {
        // code: code 
      },
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'X-Token': wx.getStorageSync("token")
      }, // 设置请求的 header
      success: res => {
        // console.log("success");
        questionData = res.data.data;
        // console.log(res);
        var days = questionData.top[0].show_day;
        arrDay = days.split("-");
        year = arrDay[0];
        month = arrDay[1];
        day = arrDay[2];
        this.setData({
          year: year,
          month: month + ' ' + '月',
          day: day,
          days:days,
          questionText: questionData.top[0].title,
          questionBg: questionData.top[0].picture_url,
          questionNum: questionData.top[0].user_answer_num+'人已答题',
          questionToAnswer: '去答题' + ' ' + '>',
          pastIforNot: questionData.top[0].has_done,
          pastRecords: questionData.body
        });
      },
      fail: e => {
        console.log("err: " + e);
      }
    })
  }
})