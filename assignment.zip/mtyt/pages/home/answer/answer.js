// pages/home/answer/answer.js
var util = require('../../../utils/util.js');
var ans_url = "https://lsq-dev.neoteched.com/v2/question_detail";
var share_url = "https://lsq-dev.neoteched.com/v2/question_share";
var quesAns_url = "https://lsq-dev.neoteched.com/v2/question_answer";
var ansData;
var arrDay;
var year,month,day
var code = wx.getStorageSync("code");
// var token = wx.getStorageSync("token");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    optionsArr: [],
    optionState: {
      a: false,
      b: false,
      c: false,
      d: false
    },
    correctOption:{
      //0是无新添样式，1正确且选中，2选中且不正确，3正确且未选中
      a: 0,
      b: 0,
      c: 0,
      d: 0
    },
    ansData: {},
    returnHome: '返回首页',
    returnHomeImg: '../../../image/return_home.png',
    questionHearten: '一道题，一则知识，每天做一题每天进步多一点',
    pastIforNot: 0,
    questionType:'1',
    questionTypeTit: '单选题',
    submiteBtnState: true,
  },
  /**
   * 事件处理函数
   */

  btnShare:function(){
    var that = this;
    // console.log(that.data.ansData.show_day)
    wx.request({
      url: share_url,
      method:"POST",
      header: {
        'content-type': 'application/json',
        'X-Token': wx.getStorageSync("token")
      },
      data:{
        day: that.data.ansData.show_day,
        width: 750,
        height: 1334
      },
      success: res => {
        console.log(res.data);
      }
    })

  },

  rHome: function () {
    wx.reLaunch({
      url: '../../home/home',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getdata();
  },


  //添加提交数据事件
  btnQuestion: function(){
    var that = this;
    var questionId = that.data.ansData.question_id.toString();
    console.log(wx.getStorageSync("token"));
    var days = that.data.ansData.show_day;
    // console.log(questionId)
    wx.request({
      url: quesAns_url,
      method:"POST",
      header:{
        'content-type': 'application/json',
        'X-Token': wx.getStorageSync("token")
      },
      data: {
        question_id: questionId,
        options: that.data.optionsArr
      },
      success: res => {
        // console.log("传输成功");
        // console.log(res);
        wx.reLaunch({
          url: '../answer/answer?days=' + days,
        })
      }
    });
  },


  //添加选项点击事件函数
  optionSelect: function (e) {
    let param = {};
    let questionType = this.data.questionType;
    if (questionType == '1') {
      this.data.optionsArr = []
      param = {
        a: false,
        b: false,
        c: false,
        d: false
      };
      this.data.optionsArr.push(e.currentTarget.id)
      param[e.currentTarget.id] = true
      this.setData({
        submiteBtnState: false
      })
    } else if (questionType == '2') {
      param = this.data.optionState
      let flag = this.data.optionsArr.indexOf(e.currentTarget.id)
      if (flag == -1) {
        this.data.optionsArr.push(e.currentTarget.id)
        param[e.currentTarget.id] = true
      } else {
        this.data.optionsArr.splice(flag, 1)
        param[e.currentTarget.id] = false
      }
      if (this.data.optionsArr.length >= 2) {
        this.setData({
          submiteBtnState: false
        })
      } else {
        this.setData({
          submiteBtnState: true
        })
      }
    }
    this.setData({
      optionState: param
    })
  },
  //定义获取数据函数
  getdata: function(){
    var that = this;
    wx.request({
      url: ans_url,
      data: {
        // code: code
        day: that.options.days
        // day:"2017-12-19"
      },
      method: 'GET',
      header: {
        'content-type': 'application/json',
        'X-Token': wx.getStorageSync("token")
      }, // 设置请求的 header
      success: res => {
        ansData = res.data.data;
        // console.log(res);
        var days = ansData.show_day;
        arrDay = days.split("-");
        year = arrDay[0];
        month = arrDay[1];
        day = arrDay[2];
        // ansData.question_content.type = 2
        let questionTypeTit = "单选题"
        if (ansData.question_content.type == 2) {
          questionTypeTit = '多选题'
        }
        
        // console.log(ansData);
        var oArr = ["a","b","c","d"];
        var uArr = ansData.user_options;
        var cArr = ansData.question_content.question.correctOption;
        let n = 0;

        for(let i of oArr){
          //在用户，在正确
          if( (uArr.indexOf(i)!=-1) && (cArr.indexOf(i)!=-1)){
            that.data.correctOption[i] = 1;
            console.log(i);
          } else if ((uArr.indexOf(i) != -1) && (cArr.indexOf(i) == -1)){
            //在用户，不在正确
            //设置红色块
            that.data.correctOption[i] = 2;
          } else if ((uArr.indexOf(i) == -1) && (cArr.indexOf(i) != -1)){
            //不在用户，在正确
            that.data.correctOption[i] = 3;
          } else {
            //不在用户，不在正确
            that.data.correctOption[i] = 0;
          }
          n++;
        }
        // console.log(that.data.correctOption);

        // //判断正确选项填充颜色
        // for (let i of ansData.question_content.question.correctOption){
        //   // console.log(i);
        //   //判断a
        //   if (i == "a") {
        //     for (let j of uArr) {
        //       if (j == i) {
        //         that.data.correctOption.a = true;
        //       } else if (j != i) {
        //         that.data.correctOption.a1 = true;
        //       }
        //     }
        //   }
        //   //判断b
        //   if (i == "b") {
        //     for (let j of uArr) {
        //       if (j == i) {
        //         that.data.correctOption.b = true;
        //       } else if (j != i) {
        //         that.data.correctOption.b1 = true;
        //       }
        //     }
        //   }
        //   //判断c
        //   if (i == "c") {
        //     for (let j of uArr) {
        //       if (j == i) {
        //         that.data.correctOption.c = true;
        //       } else if (j != i) {
        //         that.data.correctOption.c1 = true;
        //       }
        //     }
        //   }
        //   //判断d
        //   if (i == "d") {
        //     for (let j of uArr) {
        //       if (j == i) {
        //         that.data.correctOption.d = true;
        //       } else if (j != i && j == "d") {
        //         that.data.correctOption.d1 = true;
        //       }
        //     }
        //   }
        // };
        // console.log(this.data.correctOption);
        //是否完成
        let hasDone = ansData.has_done;
        //正确答案
        // ansData.question_content.question.correctOption
        let questionTure = ansData.question_content.question.correctOption.join("").toUpperCase();
            // console.log(ansData.easy_error_option);
        let fallibility = ansData.easy_error_option.toUpperCase();
        // console.log(questionTure);
        that.setData({
          ansData: res.data.data,
          day: day,
          month: month,
          year: year,
          answerTopBg: ansData.picture_url,
          questionText: ansData.title,
          context: ansData.question_content.question.context,
          A: ansData.question_content.question.a,
          B: ansData.question_content.question.b,
          C: ansData.question_content.question.c,
          D: ansData.question_content.question.d,
          hasDone: hasDone,
          questionType: ansData.question_content.type,
          questionTypeTit: questionTypeTit,
          questionTure: questionTure,//正确答案
          explanation: ansData.question_content.question.explanation,
          correctRate: ansData.correct_rate,
          fallibility: fallibility,//易错项
          question_id: ansData.question_id,
          correctOption: that.data.correctOption
        });
        // console.log(this.data)
      },
      fail: e => {
        console.log(e);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    // console.log("监听隐藏")
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})