//app.js
var Login = require('./utils/login.js');
var user
var code
App({
  onLaunch: function () {
  },
  globalData: {
    userInfo: null,
    tokenA: wx.getStorageSync("token")
  }
})


